package com.example.firestorervtemplate

import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.view.Menu
import android.view.MenuItem
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.DividerItemDecoration
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.firestorervtemplate.adapters.MyAdapter
import com.example.firestorervtemplate.databinding.ActivityMainBinding
import com.example.firestorervtemplate.models.Details
import com.google.firebase.firestore.FirebaseFirestore

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private lateinit var adapter: MyAdapter
    private lateinit var db: FirebaseFirestore

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        setSupportActionBar(binding.toolbar)

        db = FirebaseFirestore.getInstance()

        // Initialize RecyclerView and Adapter
        adapter = MyAdapter(this)
        binding.recyclerView.layoutManager = LinearLayoutManager(this)
        binding.recyclerView.addItemDecoration(
            DividerItemDecoration(
                this,
                LinearLayoutManager.VERTICAL
            )
        )
        binding.recyclerView.adapter = adapter

        // Load data from Firestore
        loadData()

        // Set up search functionality
        binding.searchView.setOnQueryTextListener(object : androidx.appcompat.widget.SearchView.OnQueryTextListener {
            override fun onQueryTextSubmit(query: String?): Boolean {
                return false
            }

            override fun onQueryTextChange(newText: String?): Boolean {
                adapter.filter(newText ?: "")
                return true
            }
        })
    }

    override fun onCreateOptionsMenu(menu: Menu): Boolean {
        menuInflater.inflate(R.menu.menu_items, menu)
        return true
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        when (item.itemId) {
            R.id.show_map -> {
                // Handle "Show on a Map" menu item click
                startActivity(Intent(this, MapsActivity::class.java))
                return true
            }
            R.id.show_list -> {
                // Handle "Show in a List" menu item click
                // Do something
                return true
            }
            R.id.watch_list -> {
                // Handle "My Watch List" menu item click
                // Do something
                startActivity(Intent(this, WatchlistActivity::class.java))
                return true
            }
            R.id.login -> {
                // Handle "Login" menu item click
                startActivity(Intent(this, LoginActivity::class.java))
                return true
            }
            R.id.logout -> {
                // Handle "Logout" menu item click
                // Do something
                startActivity(Intent(this, LogoutActivity::class.java))
                return true
            }
            else -> return super.onOptionsItemSelected(item)
        }
    }

    private fun addToWatchlist(details: Details) {
        // Implement addToWatchlist function
        // This function should add the selected property to the watchlist
        // You can use Firebase Firestore to store the property details in a collection named "Watchlist"
        // After adding to the watchlist, you may also show a confirmation message

        val watchlistCollection = db.collection("Watchlist")

        watchlistCollection.add(details)
            .addOnSuccessListener { documentReference ->
                Log.d("MainActivity", "Property added to watchlist with ID: ${documentReference.id}")
                // Show a confirmation message if needed
            }
            .addOnFailureListener { e ->
                Log.w("MainActivity", "Error adding property to watchlist", e)
                // Handle errors if needed
            }

        Log.d("MainActivity", "Added to watchlist: ${details.Propertyaddress}")
    }

    private fun loadData() {
        db.collection("Landlord")
            .get()
            .addOnSuccessListener { result ->
                val detailsList = mutableListOf<Details>()
                for (document in result) {
                    val propertyImage = document.getString("propertyImage") ?: ""
                    val numberOfBedrooms = document.getLong("numberofbedrooms")?.toInt() ?: 0
                    val propertyAddress = document.getString("propertyaddress") ?: ""
                    val rental = document.getLong("rental")?.toInt() ?: 0
                    val rentalType = document.getString("rentaltype") ?: ""
                    val details = Details(propertyImage, numberOfBedrooms, propertyAddress, rental, rentalType)
                    detailsList.add(details)
                }
                adapter.setData(detailsList)
            }
            .addOnFailureListener { exception ->
                Log.e("MainActivity", "Error getting documents: ", exception)
            }
    }
}