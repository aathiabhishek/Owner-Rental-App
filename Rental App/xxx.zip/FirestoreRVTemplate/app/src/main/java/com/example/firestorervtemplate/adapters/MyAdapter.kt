package com.example.firestorervtemplate.adapters

import android.content.Context
import android.content.Intent
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.example.firestorervtemplate.PropertyDetail
import com.example.firestorervtemplate.R
import com.example.firestorervtemplate.models.Details

class MyAdapter(private val context: Context) : RecyclerView.Adapter<MyAdapter.MyViewHolder>() {
    private var dataList = mutableListOf<Details>()
    private var filteredList = mutableListOf<Details>()

    inner class MyViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val tvAddress: TextView = itemView.findViewById(R.id.tv_address)
        val tvPrice: TextView = itemView.findViewById(R.id.tv_price)
        val ivPropertyImage: ImageView = itemView.findViewById(R.id.iv_property_image)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): MyViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.item_property, parent, false)
        return MyViewHolder(view)
    }

    override fun getItemCount(): Int {
        return filteredList.size
    }

    override fun onBindViewHolder(holder: MyViewHolder, position: Int) {
        val currItem = filteredList[position]

        holder.tvAddress.text = currItem.Propertyaddress
        holder.tvPrice.text = "Monthly price: ${currItem.Rental}, Bedrooms: ${currItem.Numberofbedrooms}"

        Glide.with(holder.itemView.context)
            .load(currItem.PropertyImage)
            .into(holder.ivPropertyImage)

        holder.itemView.setOnClickListener {
            // Create Intent to open PropertyDetailsActivity
            val intent = Intent(context, PropertyDetail::class.java).apply {
                // Pass the property details as extras
                putExtra("propertyImage", currItem.PropertyImage)
                putExtra("numberOfBedrooms", currItem.Numberofbedrooms)
                putExtra("propertyAddress", currItem.Propertyaddress)
                putExtra("rental", currItem.Rental)
                putExtra("rentalType", currItem.Rentaltype)
            }
            // Start PropertyDetailsActivity
            context.startActivity(intent)
        }
    }

    fun setData(data: List<Details>) {
        dataList.clear()
        dataList.addAll(data)
        filteredList.clear()
        filteredList.addAll(data)
        notifyDataSetChanged()
    }

    fun filter(text: String) {
        filteredList.clear()
        if (text.isEmpty()) {
            filteredList.addAll(dataList)
        } else {
            val searchText = text.toLowerCase().trim()
            dataList.forEach { item ->
                if (item.Propertyaddress.toLowerCase().contains(searchText)) {
                    filteredList.add(item)
                }
            }
        }
        notifyDataSetChanged()
    }
}