package com.example.firestorervtemplate

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity

class MapActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_map) // Assuming you have a layout file named activity_map.xml
        // Initialize your map view or any other map-related functionality here
    }
}